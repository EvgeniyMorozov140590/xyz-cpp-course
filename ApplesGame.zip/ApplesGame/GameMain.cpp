﻿// ©2023, XYZ School. All rights reserved.
// Authored by Aleksandr Rybalka (polterageist@gmail.com)

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;
const float INITIAL_SPEED = 100.f;
const float PLAYER_SIZE = 20.f;
const float ACCELERATION = 10.f;

const int NUM_APPLES = 20;
const float APPLE_SIZE = 20.f;

const float ROCK_SIZE = 50.f;
const int NUM_ROCKS = 20;

const std::string RESOURCES_PATH = "Resources/";

struct Vector2D
{
	float x = 0;
	float y = 0;
};

enum class PlayerDirection
{
	Right = 0,
	Up,
	Left,
	Down
};

typedef Vector2D Position2D;

int main()
{	
	int seed = (int)time(nullptr);

	srand(seed);

	sf::RenderWindow window(sf::VideoMode(SCREEN_WIDTH, SCREEN_HEIGHT), "Apples game");


	Position2D playerPosition = { SCREEN_WIDTH / 2.f, SCREEN_HEIGHT / 2.f };

	float playerSpeed = INITIAL_SPEED;
	PlayerDirection playerDirection = PlayerDirection::Right;

	sf::RectangleShape playerShape;

	playerShape.setSize(sf::Vector2f(PLAYER_SIZE, PLAYER_SIZE));
	playerShape.setFillColor(sf::Color::Red);
	playerShape.setOrigin(PLAYER_SIZE / 2.f, PLAYER_SIZE / 2.f);
	playerShape.setPosition(playerPosition.x, playerPosition.y);

	Position2D applesPositions[NUM_APPLES];
	sf::CircleShape applesShape[NUM_APPLES];

	for (int i = 0; i < NUM_APPLES; i++)
	{	
		applesPositions[i].x = rand() / (float)RAND_MAX * SCREEN_WIDTH;
		applesPositions[i].y = rand() / (float)RAND_MAX * SCREEN_HEIGHT;

		applesShape[i].setRadius(APPLE_SIZE / 2.f);
		applesShape[i].setFillColor(sf::Color::Green);
		applesShape[i].setOrigin(APPLE_SIZE / 2.f, APPLE_SIZE / 2.f);
		applesShape[i].setPosition(applesPositions[i].x, applesPositions[i].y);
	}

	int numEatenApples = 0;

	float rocksX[NUM_ROCKS];
	float rocksY[NUM_ROCKS];

	sf::RectangleShape rocksShape[NUM_ROCKS];

	for (int i = 0; i < NUM_ROCKS; i++)
	{
		int minX = 0;
		int minY = 0;
		int maxX = SCREEN_WIDTH / 2 - PLAYER_SIZE - ROCK_SIZE;
		int maxY = SCREEN_HEIGHT - PLAYER_SIZE - ROCK_SIZE;

		if (i > NUM_ROCKS / 2) {
			minX = SCREEN_WIDTH / 2 + PLAYER_SIZE + ROCK_SIZE;
			maxX = SCREEN_WIDTH - ROCK_SIZE;
		}

		rocksX[i] = minX + rand() % maxX;
		rocksY[i] = minY + rand() % maxY;

		rocksShape[i].setSize(sf::Vector2f(ROCK_SIZE, ROCK_SIZE));
		rocksShape[i].setFillColor(sf::Color::Yellow);
		rocksShape[i].setOrigin(ROCK_SIZE / 2.f, ROCK_SIZE / 2.f);
		rocksShape[i].setPosition(rocksX[i], rocksY[i]);
	}

	sf::Clock gameClock;
	float lastTime = gameClock.getElapsedTime().asSeconds();
	float startDelay = 1.f;

	bool isGameOver = false;

	while (window.isOpen())
	{
		sf::Event event;

		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed) 
			{
				window.close();
			}
				
		}

		float currentTime = gameClock.getElapsedTime().asSeconds();
		float deltaTime = currentTime - lastTime;
		lastTime = currentTime;

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
		{
			if (isGameOver)
			{
				playerPosition.x = SCREEN_WIDTH / 2.f;
				playerPosition.y = SCREEN_HEIGHT / 2.f;
				playerSpeed = INITIAL_SPEED;
				numEatenApples = 0;
				playerDirection = PlayerDirection::Right;

				for (int i = 0; i < NUM_APPLES; i++)
				{
					applesPositions[i].x = rand() / (float)RAND_MAX * SCREEN_WIDTH;
					applesPositions[i].y = rand() / (float)RAND_MAX * SCREEN_HEIGHT;

					applesShape[i].setPosition(applesPositions[i].x, applesPositions[i].y);
				}

				for (int i = 0; i < NUM_ROCKS; i++)
				{
					float minX = 0.f;
					float minY = 0.f;
					float maxX = SCREEN_WIDTH / 2 - PLAYER_SIZE - ROCK_SIZE;
					float maxY = SCREEN_HEIGHT;

					if (i > NUM_ROCKS / 2) {
						minX = SCREEN_WIDTH / 2 + PLAYER_SIZE + ROCK_SIZE;
						maxX = SCREEN_WIDTH;
					}

					rocksX[i] = minX + rand() % (int)maxX;
					rocksY[i] = minY + rand() % (int)maxY;

					rocksShape[i].setPosition(rocksX[i], rocksY[i]);
				}

				gameClock.restart();

				isGameOver = false;
			}
		}

		if (!isGameOver && currentTime > startDelay)
		{
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
			{
				playerDirection = PlayerDirection::Right;
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
			{
				playerDirection = PlayerDirection::Up;
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
			{
				playerDirection = PlayerDirection::Left;
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
			{
				playerDirection = PlayerDirection::Down;
			}

			switch (playerDirection)
			{
				case PlayerDirection::Right:
				{
					playerPosition.x += playerSpeed * deltaTime;
					break;
				}
				case PlayerDirection::Up:
				{
					playerPosition.y -= playerSpeed * deltaTime;
					break;
				}
				case PlayerDirection::Left:
				{
					playerPosition.x -= playerSpeed * deltaTime;
					break;
				}
				case PlayerDirection::Down:
				{
					playerPosition.y += playerSpeed * deltaTime;
					break;
				}
			}

			if (playerPosition.x - PLAYER_SIZE / 2.f < 0.f || playerPosition.x + PLAYER_SIZE / 2.f > SCREEN_WIDTH
				|| playerPosition.y - PLAYER_SIZE / 2.f < 0.f || playerPosition.y + PLAYER_SIZE / 2.f > SCREEN_HEIGHT)
			{
				isGameOver = true;
			}

			playerSpeed += ACCELERATION * deltaTime;

			for (int i = 0; i < NUM_APPLES; i++)
			{
				float squaredistance = (playerPosition.x - applesPositions[i].x) * (playerPosition.x - applesPositions[i].x) +
					(playerPosition.y - applesPositions[i].y) * (playerPosition.y - applesPositions[i].y);
				float squareRadius = (APPLE_SIZE + PLAYER_SIZE) * (APPLE_SIZE + PLAYER_SIZE) / 4;

				if (squaredistance <= squareRadius)
				{
					++numEatenApples;

					applesPositions[i].x = rand() / (float)RAND_MAX * SCREEN_WIDTH;
					applesPositions[i].y = rand() / (float)RAND_MAX * SCREEN_HEIGHT;

					applesShape[i].setRadius(APPLE_SIZE / 2.f);
					applesShape[i].setFillColor(sf::Color::Green);
					applesShape[i].setOrigin(APPLE_SIZE / 2.f, APPLE_SIZE / 2.f);
					applesShape[i].setPosition(applesPositions[i].x, applesPositions[i].y);
				}
			}

			for (int i = 0; i < NUM_ROCKS; i++)
			{
				float dx = fabs(playerPosition.x - rocksX[i]);
				float dy = fabs(playerPosition.y - rocksY[i]);

				if (dx <= (ROCK_SIZE + PLAYER_SIZE) / 2.f &&
					dy <= (ROCK_SIZE + PLAYER_SIZE) / 2.f)
				{
					isGameOver = true;
				}
			}
		}

		window.clear();

		playerShape.setPosition(playerPosition.x, playerPosition.y);

		for (int i = 0; i < NUM_APPLES; i++)
		{
			window.draw(applesShape[i]);
		}

		for (int i = 0; i < NUM_ROCKS; i++)
		{
			window.draw(rocksShape[i]);
		}

		window.draw(playerShape);

		window.display();
	}

	return 0;
}
